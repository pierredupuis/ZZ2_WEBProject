﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer
{
    public abstract class WarModel : EntityObject
    {
        public List<Fight> Fights { get; set; }
        public List<House> Alliance1 { get; set; }
        public List<House> Alliance2 { get; set; }

        public WarModel(War w)
        {
            Fights = w.Fights;
            Alliance1 = w.Alliance1;
            Alliance2 = w.Alliance2;
        }

    }
}
