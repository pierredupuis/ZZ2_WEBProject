﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer
{

    public class CharacterModel : EntityObject
    {

        [Display(Name = "First Name")]
        public String FirstName { get; set; }

        [Display(Name = "Last Name")]
        public String LastName { get; set; }

        [Display(Name = "Bravoury")]
        public int Bravoury { get; set; }

        [Display(Name = "Crazyness")]
        public int Crazyness { get; set; }

        [Display(Name = "Strength")]
        public int Strength { get; set; }

        [Display(Name = "Health Points")]
        public int HP { get; set; }

        [Display(Name = "Maximum Health Points")]
        public int HPMax { get; set; }

        //Dictionary<Character, RelationshipEnum> Relationships;

        public CharacterModel(Character c)
        {
            Bravoury = c.Bravoury;
            Crazyness = c.Crazyness;
            Strength = c.Strength;
            FirstName = c.FirstName;
            LastName = c.LastName;
            HP = c.HP;
            HPMax = c.HPMax;
        }

    }
}
