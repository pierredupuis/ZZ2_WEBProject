﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer
{

    public class TerritoryModel : EntityObject
    {

        public TerritoryTypeEnum TerritoryType { get; set; }
        public House Owner { get; set; }
        
        public TerritoryModel(Territory t)
        {
            TerritoryType = t.TerritoryType;
        }
    }
}
