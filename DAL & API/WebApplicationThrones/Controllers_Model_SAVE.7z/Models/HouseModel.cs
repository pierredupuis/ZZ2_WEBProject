﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EntitiesLayer;
using System.ComponentModel.DataAnnotations;

namespace WebApplicationThrones.Models
{
    public class HouseModel
    {
        [Display(Name="Nom")]
        public String Name { get; set; }

        [Display(Name = "Nombre d'unités")]
        public int NumberOfUnits { get; set; }

        public HouseModel(House h)
        {
            Name = h.Name;
            NumberOfUnits = h.NumberOfUnits;
        }
    }
}